#include "display/lv_misc/lv_color.h"
#include "main.h"

lv_obj_t *DisplayControl::mtabview = lv_tabview_create(lv_scr_act(), NULL); // creates the tabview

//lv_obj_t *DisplayControl::mtabview_odom = lv_tabview_add_tab(
//    DisplayControl::mtabview,
//    "Odom"); // creates the tab on the screen that shows the calculated robot position

lv_obj_t *DisplayControl::mtabview_auton = lv_tabview_add_tab(
    DisplayControl::mtabview, "Auton"); // creates the tab with the auton selection dropdown
lv_obj_t *DisplayControl::mtabview_auton_dropdown =
    lv_ddlist_create(mtabview_auton, NULL); // creates the auton selection dropdown
lv_obj_t *DisplayControl::mtabview_auton_dropdown_side =
    lv_ddlist_create(mtabview_auton, NULL); // creates the side selection dropdown
lv_obj_t *DisplayControl::mtabview_auton_dropdown_color =
    lv_ddlist_create(mtabview_auton, NULL); // creates the color selection dropdown
lv_res_t DisplayControl::tabview_auton_dropdowns_action(
    lv_obj_t *idropdown) // specifies the code to be executed when the auton dropdown is changed
{
    FILE *file;                    // creates an object that will be used to reference the file containing the
                                   // selected auton
    if (pros::usd::is_installed()) // makes sure the sd card is installed before trying to access
                                   // its contents
    {
        file = fopen("/usd/auton_settings.txt", "w"); // opens the auton settings file
        if (file)                                     // makes sure the file was accessed correctly
        {
            fprintf(file, "%i",
                    (lv_ddlist_get_selected(mtabview_auton_dropdown) 
                    * 100
                     + lv_ddlist_get_selected(mtabview_auton_dropdown_side) 
                     * 10 + lv_ddlist_get_selected(mtabview_auton_dropdown_color))); // update sd card based on new value
            std::cout << "set /usd/auton_settings.txt to "
                      << std::to_string(lv_ddlist_get_selected(mtabview_auton_dropdown) 
                      * 100 + lv_ddlist_get_selected(mtabview_auton_dropdown_side) 
                      * 10 + lv_ddlist_get_selected(mtabview_auton_dropdown_color))
                      << std::endl;
        }
        else
        {
            std::cout
                << "/usd/auton_settings.txt is null"
                << std::endl; // output to the terminal if the sd card was not accessed correctly
        }
        fclose(file);
        // Auton::readSettings(); // update auton based on new sd card values
    }

    return LV_RES_OK; // required for dropdown callback
}

//Styles

lv_style_t DisplayControl::mstyle_tabview_indic;
lv_style_t DisplayControl::mstyle_tabview_btn;
lv_style_t DisplayControl::mstyle_tabview_btn_tgl;
lv_style_t DisplayControl::mstyle_tabview_btn_pr;
lv_style_t DisplayControl::mstyle_tabview_container;
lv_style_t DisplayControl::mstyle_text;

lv_obj_t *DisplayControl::mtabview_misc =
    lv_tabview_add_tab(DisplayControl::mtabview, "Misc"); // creates the miscelaneus debugging tab
lv_obj_t *DisplayControl::mtabview_misc_container =
    lv_obj_create(DisplayControl::mtabview_misc, NULL);
lv_obj_t *DisplayControl::mtabview_misc_label =
    lv_label_create(mtabview_misc_container, NULL); // creates the left text box
lv_obj_t *DisplayControl::mtabview_misc_label_2 =
    lv_label_create(mtabview_misc_container, NULL); // creates the right text bo
lv_obj_t *DisplayControl::mtabview_misc_label_3 =
    lv_label_create(mtabview_misc_container, NULL); // creates the right text bo
lv_obj_t *DisplayControl::mtabview_misc_label_4 =
    lv_label_create(mtabview_misc_container, NULL); // creates the right text bo

DisplayControl::DisplayControl()
{
    /* ----------------------- Style Setup ----------------------- /
     * Specifies what each style should look like when they are used.
     */
    lv_style_copy(&mstyle_tabview_indic, &lv_style_plain);
    mstyle_tabview_indic.body.padding.inner = 5;

    lv_style_copy(&mstyle_tabview_btn, &lv_style_plain);
    mstyle_tabview_btn.body.main_color = LV_COLOR_PURPLE;
    mstyle_tabview_btn.body.grad_color = LV_COLOR_PURPLE;
    mstyle_tabview_btn.text.color = LV_COLOR_WHITE;
    mstyle_tabview_btn.body.border.part = LV_BORDER_BOTTOM;
    mstyle_tabview_btn.body.border.color = LV_COLOR_WHITE;
    mstyle_tabview_btn.body.border.width = 1;
    mstyle_tabview_btn.body.padding.ver = 4;

    lv_style_copy(&mstyle_tabview_btn_tgl, &mstyle_tabview_btn);
    mstyle_tabview_btn_tgl.body.border.part = LV_BORDER_FULL;
    mstyle_tabview_btn_tgl.body.border.width = 2;

    lv_style_copy(&mstyle_tabview_btn_pr, &lv_style_plain);
    mstyle_tabview_btn_pr.body.main_color = LV_COLOR_WHITE;
    mstyle_tabview_btn_pr.body.grad_color = LV_COLOR_WHITE;
    mstyle_tabview_btn_pr.text.color = LV_COLOR_WHITE;

    lv_style_copy(&mstyle_tabview_container, &lv_style_plain_color);
    mstyle_tabview_container.body.main_color = LV_COLOR_PURPLE;
    mstyle_tabview_container.body.grad_color = LV_COLOR_PURPLE;
    mstyle_tabview_container.body.border.width = 0;
    mstyle_tabview_container.body.radius = 0;
    mstyle_tabview_container.body.padding.inner = 0;
    mstyle_tabview_container.body.padding.hor = 0;
    mstyle_tabview_container.body.padding.ver = 0;

    lv_style_copy(&mstyle_text, &lv_style_plain);
    mstyle_text.text.color = LV_COLOR_WHITE;
    mstyle_text.text.opa = LV_OPA_100;

    lv_tabview_set_style(mtabview, LV_TABVIEW_STYLE_INDIC,
                         &mstyle_tabview_indic); // set tabview styles
    lv_tabview_set_style(mtabview, LV_TABVIEW_STYLE_BTN_REL, &mstyle_tabview_btn);
    lv_tabview_set_style(mtabview, LV_TABVIEW_STYLE_BTN_PR, &mstyle_tabview_btn_pr);
    lv_tabview_set_style(mtabview, LV_TABVIEW_STYLE_BTN_TGL_REL, &mstyle_tabview_btn_tgl);
    lv_tabview_set_style(mtabview, LV_TABVIEW_STYLE_BTN_TGL_PR, &mstyle_tabview_btn_pr);

    /* ------------------------ Auton Tab ------------------------  /
     * When making autons, you must add the text this dropdown, a new
     * enum value in Auton.hpp, and a new case in the switch in Auton.cpp.
     */
    lv_ddlist_set_options(mtabview_auton_dropdown, "None\n"
                                                    "Test\n"
                                                    "AWP\n"
                                                    "R_High\n"
                                                    "R_Safe\n"
                                                    "L_High\n"
                                                    "L_Safe\n"
                                                    "skills\n"
                                                   ); // auton types in selection dropdown
    lv_ddlist_set_options(mtabview_auton_dropdown_side, "Right\n"
                                                        "Left\n"); // color selector
    lv_ddlist_set_options(mtabview_auton_dropdown_color, "Red\n"
                                                         "Blue\n"); // color selector

    lv_ddlist_set_action(mtabview_auton_dropdown,
                         tabview_auton_dropdowns_action); // set the dropdown callback to
                                                          // tabview_auton_dropdown_action()
    lv_ddlist_set_action(mtabview_auton_dropdown_side, tabview_auton_dropdowns_action);
    lv_ddlist_set_action(mtabview_auton_dropdown_color, tabview_auton_dropdowns_action);

    lv_obj_align(mtabview_auton_dropdown_color, NULL, LV_ALIGN_IN_TOP_RIGHT, 0, 0);
    lv_obj_align(mtabview_auton_dropdown_side, NULL, LV_ALIGN_IN_TOP_MID, 0, 0);
    lv_obj_align(mtabview_auton_dropdown, NULL, LV_ALIGN_IN_TOP_LEFT, 0,
                 0); // align the dropdown in the top left
    lv_ddlist_set_fix_height(mtabview_auton_dropdown, 200);

    lv_obj_set_style(mtabview_auton, &mstyle_tabview_container); // set styles

    /* ------------------------- Misc Tab ------------------------ */
    lv_page_set_sb_mode(mtabview_misc, LV_SB_MODE_OFF); // hide scrollbar

    lv_obj_set_style(mtabview_misc, &mstyle_tabview_container); // set styles
    lv_obj_set_style(mtabview_misc_container, &mstyle_tabview_container);
    lv_obj_set_size(mtabview_misc_container, lv_obj_get_width(mtabview_misc),
                    lv_obj_get_height(mtabview_misc)); // set up the background
    lv_obj_align(mtabview_misc_container, NULL, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style(mtabview_misc_label, &mstyle_text); // set up text boxes (labels)
    lv_obj_set_style(mtabview_misc_label_2, &mstyle_text);

    lv_label_set_text(mtabview_misc_label, "No data provided."); // set default text for labels
    lv_label_set_text(mtabview_misc_label_2, "No data provided."); // To be no data provided
    lv_label_set_text(mtabview_misc_label_3, "No data provided."); // set default text for labels
    lv_label_set_text(mtabview_misc_label_4, "No data provided."); // To be no data provided

    lv_obj_align(mtabview_misc_label, mtabview_misc_container, LV_ALIGN_IN_TOP_LEFT, 0, 0); // align labels
    lv_obj_align(mtabview_misc_label_2, mtabview_misc_container, LV_ALIGN_IN_TOP_RIGHT, -70, 0);
    lv_obj_align(mtabview_misc_label_3, mtabview_misc_container, LV_ALIGN_IN_LEFT_MID, 0, 0);
    lv_obj_align(mtabview_misc_label_4, mtabview_misc_container, LV_ALIGN_IN_RIGHT_MID, -70, 0);

}


void DisplayControl::setAutonDropMen() // update the auton dropdown to match the sd card
{
    lv_ddlist_set_selected(mtabview_auton_dropdown, (int)Auton::auton);
    lv_ddlist_set_selected(mtabview_auton_dropdown_side, (int)Auton::side);
    lv_ddlist_set_selected(mtabview_auton_dropdown_color, (int)Auton::color);
}

void DisplayControl::setMiscData(int ilabel,
                                 std::string itext) // set the text on text box (label) 1 or 2
{
    if (ilabel == 1)
    {
        lv_label_set_text(mtabview_misc_label, itext.c_str());
    }
    else if (ilabel == 2)
    {
        lv_label_set_text(mtabview_misc_label_2, itext.c_str());
    }
    else if (ilabel == 3)
    {
        lv_label_set_text(mtabview_misc_label_3, itext.c_str());
    }
    else if (ilabel == 4)
    {
        lv_label_set_text(mtabview_misc_label_4, itext.c_str());
    }
}