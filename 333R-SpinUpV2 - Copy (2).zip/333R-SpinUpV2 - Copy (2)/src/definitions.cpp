#include "definitions.hpp"
#include "main.h"
#include "okapi/impl/device/rotarysensor/adiEncoder.hpp"
#include "pros/adi.hpp"
#include "pros/distance.hpp"
#include "pros/gps.hpp"
#include "pros/optical.hpp"
#include "stateMachines/FlywheelStateMachine.hpp"


namespace def{
//--------------------------------------------------------------------//
//-----------------------------MOTORS---------------------------------//
//--------------------------------------------------------------------//

//-----------Drivetrain Motors
Motor mtr_dt_left_front(-15); //1
Motor mtr_dt_left_mid(-16);
Motor mtr_dt_left_back(-17); //4
Motor mtr_dt_right_front(18); //2
Motor mtr_dt_right_mid(19);
Motor mtr_dt_right_back(20); //3

//Motor mtr_dt_right_mid(15);
//Motor mtr_dt_left_mid(6);

//-----------Indexer Motor-----
//Motor mtr_ix(-5);

//-----------Intake Motors------
Motor mtr_it_m(10);

//Flywheel Motors
Motor mtr_fw_fw(9);
//Motor mtr_fw_fw2(-8);


//Pnumatics
pros::ADIDigitalOut sol_endg('A');
//--------------------------------------------------------------------//
//-----------------------------SENSORS--------------------------------//
//--------------------------------------------------------------------//

//Encoders
ADIEncoder track_encoder_side('C', 'D', true);

//LEDS
//pros::ADILed led('B', 23);

//-----------Inertial Sensors
pros::Imu imu_side(13);
pros::Imu imu_top(14);
pros::Imu imu_back(2);


//Rotation Sensors
//RotationSensor fwr(10, false);

//Vision Sensor
//pros::Vision v_front(11);

//Color Sensors
pros::Optical o_rollerR(4);
pros::Optical o_rollerL(3);

//pros::Optical o_flash(18);

//Distance Sensors
pros::Distance d_backL(7);
pros::Distance d_backR(8);

pros::Distance d_frontL(12);
pros::Distance d_frontR(5);

pros::Distance d_discs(6);

//Radio at port 21

//GPS Sensors
//pros::GPS g_gps8(18, -0.1016, -0.2413, 180);
//pros::c::gps_gyro_s_t gyroRaw;

//--------------------------------------------------------------------//
//-----------------------------CONTROLLER-----------------------------//
//--------------------------------------------------------------------//

//-----------Controller
Controller controller = Controller();

//Controller Button Definitions
ControllerButton btn_indexer_spin = ControllerDigital::L2;

ControllerButton btn_fw_shoot = ControllerDigital::L1;

ControllerButton btn_fw_up = ControllerDigital::up;
ControllerButton btn_fw_down = ControllerDigital::down;


ControllerButton btn_intake_toggle = ControllerDigital::X;
ControllerButton btn_intake_toggleout = ControllerDigital::Y;
ControllerButton btn_intake_in = ControllerDigital::R2;
ControllerButton btn_intake_out = ControllerDigital::R1;

ControllerButton btn_end_on = ControllerDigital::left;
ControllerButton btn_end_on2 = ControllerDigital::right;

// State Machince Definitions
CustomOdometry customOdom = CustomOdometry(); // object that calculates position

Drivetrain drivetrain = Drivetrain(); // used by DrivetrainStateMachine for drivetrain control

DrivetrainStateMachine sm_dt = DrivetrainStateMachine(); // state machine to control the drivetrain

const double DRIVE_STRAIGHT_SCALE = 1922;
const double DRIVE_TURN_SCALE = 15;
const QSpeed DRIVE_MAX_SPEED = 1.3_mps;      // a measured linear velocity
const QAcceleration DRIVE_MAX_ACCEL = 1.1_G; // approxamate measured linear acceleration
}
