#include "Auton.hpp"
#include "definitions.hpp"
#include "main.h"
#include "pros/apix.h"
#include "pros/rtos.hpp"
#include "stateMachines/DrivetrainStateMachine.hpp"
#include "stateMachines/FlywheelStateMachine.hpp"
#include "stateMachines/IntakeStateMachine.hpp"
#include "util/drivetrain.hpp"


// ------------------------Auton.cpp-----------------------------------------//
// This file is being used to control the different robot movements during   //
// the autonomous period. We have different enumerations depending on which  //
// color side and auton is selected. This allows us to be able to use our    //
// autons more effciently so we don't have to make a bunch of different      //
// autonomous programs depending on for example the color that we were given //
// We also use this file where we upload the current selected auton from the //
// brain to be able to always have it available. Then we have the different  //
// movements that we have written down below.                                //
/*---------------------------------------------------------------------------*/

Auton::Autons Auton::auton;    // default auton is deploy, if the sd card is not installed
Auton::Sides Auton::side;      // default side is Right if the sd card is not installed
Auton::Colors Auton::color;    // default color is Red if the sd card is not installed
Auton::Colors Auton::opponent; // default color is Red if the sd card is not installed

//bool cEnable = false;

void Auton::readSettings() // read the sd card to set the settings
{
    FILE *file;                    // cpp a file object to be used later
    if (pros::usd::is_installed()) // checks if the sd card is installed before trying to read it
    {
        file = fopen("/usd/auton_settings.txt", "r"); // open the auton settings
        if (file)                                     // check to see if the file opened correctly
        {
            int autonSideAndColor; 
            fscanf(file, "%i", &autonSideAndColor);

            auton = (Auton::Autons)(autonSideAndColor / 100);
            side = (Auton::Sides)((autonSideAndColor / 10) % 10);
            color = (Auton::Colors)(autonSideAndColor % 10);
            opponent = color == Auton::Colors::Red ? Auton::Colors::Blue : Auton::Colors::Red;

            std::cout << "autonSideAndColor in sd card is " //prints to the terminal
            << std::to_string(autonSideAndColor) << ". Auton is " // the side
            << (int)auton << ", side is " << (int)side << ", and color is " << (int)color << "." << std::endl; // color
            // and the auton selected
        }
        else
        {
            std::cout << "/usd/auton_settings.txt is null."
                      << std::endl; // if the file didn't open right, tell the terminal
        }
        fclose(file); // close the file
    }
}
void Auton::suspendAsyncTask()
{
    masync_task.suspend();
}


bool Auton::cEnable()
{
    bool cEn = false;
    switch(color)//sequence loop to run the selected color
    {
        case Colors::Red:
            cEn = true;
        break; 
        case Colors::Blue:
            cEn = false;
        break;
    }
    return cEn;  
}

void Auton::runAuton(){ // Function that controls all of the autonomous movements
    Auton::readSettings(); //Loads the autons from the SD card
    Auton::suspendAsyncTask(); //Stops the async tasks

    mstartTime = mtimer.millis(); // Timer for the auton
    waitForImu(); // Wait for calibration
    Auton::cEnable();
    CustomOdometry::setStateInitial({0_in, 0_in, -def::imu_side.get_rotation() * degree});
    //Setting the initial state and then disabiling the controls
    DrivetrainStateMachine::disableControl();
    FlywheelStateMachine::disableControl();
    IntakeStateMachine::disableControl();
    //IndexerStateMachine::disableControl();
    EndGameStateMachine::disableControl();
    //Sets the states to disable controller inputs
    DrivetrainStateMachine::setState(DT_STATES::busy);

    switch (auton){ //Sequence loop to contain the different autons

        case Autons::none:
            //Doing Nothing
        break;

        case Autons::Test: // Used to Implement Test Auton code 
            // Remove the display button during matches to prevent accidents
            Drivetrain::moveBack(91); //Move toward the roller
            IntakeStateMachine::RollerColor(); //roll the colr
            Drivetrain::straightForDistance(5_in); // drive back
            Drivetrain::turn(-13_deg);//turn to goal
            FlywheelStateMachine::AShoot(12000); //Shoots the fly
            //Drivetrain::turn(35_deg);//turns to the other side
            //IntakeStateMachine::setState(INTAKE_STATES::in);//starts the intake
            //Drivetrain::straightForDistance(5.5_ft);//drives to middle
            //Drivetrain::turn(-35_deg);//faces the goal
        break;

        case Autons::AWP:

        /* This code was great, but we need to change it
            IntakeStateMachine::setState(INTAKE_STATES::out);
            Drivetrain::moveBack(70);
            pros::delay(125);
            IntakeStateMachine::setState(INTAKE_STATES::off);
            Drivetrain::straightForDistance(6_in);
            Drivetrain::turn(48_deg);
            Drivetrain::straightForDistance(6_ft);
            Drivetrain::turn(-45_deg);
            Drivetrain::straightForDistance(11_in);
            Drivetrain::turn(10_deg);
            FlywheelStateMachine::setState(FW_STATES::shoot);
            pros::delay(3000);
            IntakeStateMachine::setState(INTAKE_STATES::in);
            */
        break;
        
        case Autons::R_High:
             Drivetrain::straightForDistance(-1.5_ft);
             Drivetrain::turn(-90_deg);
        break;

        case Autons::R_Safe: // here
            IntakeStateMachine::setState(INTAKE_STATES::out);// Starts the intake for the roller
             //Drive Toward the roller
            Drivetrain::moveBack(70); //Move toward the roller
                pros::delay(125);
            IntakeStateMachine::setState(INTAKE_STATES::off);
            //IntakeStateMachine::setState(INTAKE_STATES::Skills);//Roll to the correct color
            Drivetrain::straightForDistance(6_in); //Go back to start
            Drivetrain::turn(90_deg);// Turn to face the low goal
            FlywheelStateMachine::setState(FW_STATES::a2); //Shoots the two preloads into the low goal
            //IntakeStateMachine::setState(INTAKE_STATES::out);//Starts the intake 
            //Drivetrain::straightForDistance(0_in);//Drives towards first set of discs
            //Drivetrain::straightForDistance(0_in);//Drives towards the next set of discs
            //Drivetrain::turn(0_deg);//Turn towards the low goal
            //FlywheelStateMachine::setState(FW_STATES::a2);//Fires the last set of discs into the low goal
        break;

        case Autons::L_High:
            FlywheelStateMachine::setState(FW_STATES::a2);//Fires the two preloads into the low goal
            Drivetrain::straightForDistance(0_in);//Drives towards the roller
            Drivetrain::turn(0_deg);//Turn to face towards the roller
            Drivetrain::moveBack(0);//Backward distance function goes here
            //IntakeStateMachine::setState(INTAKE_STATES::RollerColor);//Roll to the color
            Drivetrain::straightForDistance(0_in);//Drives away from the roller
            Drivetrain::turn(0_deg);//Turns to face the other side of the field
            IntakeStateMachine::setState(INTAKE_STATES::in);//Starts the roller
            Drivetrain::straightForDistance(0_in);//Drives towards the first set of discs
            Drivetrain::straightForDistance(0_in);//Drives toward the second set of discs
            Drivetrain::turn(0_deg);//Turns towards the high goal
            FlywheelStateMachine::setState(FW_STATES::a2);//Fires towards the high goal
            Drivetrain::turn(0_deg);//Turn back to face the final set of discs
            Drivetrain::straightForDistance(0_in);//Drives towards the final set of discs
            Drivetrain::turn(0_deg);//Turns to face the low goal
            Drivetrain::straightForDistance(0_in);//Drives towards the low goal
            FlywheelStateMachine::setState(FW_STATES::a2);//Fires into the low goal
        break;

        case Autons::L_Safe:
        FlywheelStateMachine::setState(FW_STATES::shoot);
        pros::delay(3000);
        IntakeStateMachine::setState(INTAKE_STATES::in);

        /*
            FlywheelStateMachine::setState(FW_STATES::a2);//Fires the two preloads into the low goal
            Drivetrain::straightForDistance(0_in);//Drives towards the roller
            Drivetrain::turn(0_deg);//Turn to face towards the roller
            Drivetrain::moveBack(0);//Backward distance function goes here
            IntakeStateMachine::setState(INTAKE_STATES::Skills);//Roll to the color
            Drivetrain::straightForDistance(0_in);//Drives away from the roller
            Drivetrain::turn(0_deg);//Turns to face the other side of the field
            IntakeStateMachine::setState(INTAKE_STATES::in);//Starts the roller
            Drivetrain::straightForDistance(0_in);//Drives towards the first set of discs
            Drivetrain::straightForDistance(0_in);//Drives toward the second set of discs
            Drivetrain::straightForDistance(0_in);//Drives towards the third set of discs
            Drivetrain::turn(0_deg);//Turns towards the low goal
            Drivetrain::straightForDistance(0_in);//Drives towards the low goal
            FlywheelStateMachine::setState(FW_STATES::a2); //Fires into the low goal
            */
        break;

        case Autons::skills: // Skills run
            Drivetrain::moveDist();
            //    IntakeStateMachine::setState(INTAKE_STATES::RollerColor);//Roll the color 1/4
            Drivetrain::straightForDistance(0_in);//Backs away from the roller
            Drivetrain::turn(0_deg);//Drivetrain Turns to face the field
            //    IntakeStateMachine::setState(INTAKE_STATES::RollerColor); //Starts the Intake
            Drivetrain::straightForDistance(0_in);//Drives to the first discs
            Drivetrain::straightForDistance(0_in);//Drives to the second disc
            Drivetrain::straightForDistance(0_in);//Drives to the third discs
            Drivetrain::turn(0_deg);//Turns to face the High goal
                IntakeStateMachine::setState(INTAKE_STATES::off);//Stops the intake
            Drivetrain::moveBack(0); //Moves back to the curb
                FlywheelStateMachine::setState(FW_STATES::a2);//Shoots into the high goal
            Drivetrain::straightForDistance(0_in);//Drives back away from the high goal
            Drivetrain::turn(0_deg);//Drivetrain turns to face the other end of the field
            Drivetrain::straightForDistance(0_in);//Drives towards the other end of the field
            Drivetrain::turn(0_deg);//Turns to face the roller
            Drivetrain::moveDist();//Drives to the roller
            //    IntakeStateMachine::setState(INTAKE_STATES::RollerColor);//Roll the color 2/4
            Drivetrain::straightForDistance(0_in);//Drives Away from the roller
            Drivetrain::turn(0_deg);//Turns to face the other roller
            Drivetrain::moveDist();//Moves up to the next roller
            //    IntakeStateMachine::setState(INTAKE_STATES::RollerColor);//Roll the Color 3/4
            Drivetrain::straightForDistance(0_in);//Drives back from the roller
            Drivetrain::turn(0_deg);//turns back to face the field
                IntakeStateMachine::setState(INTAKE_STATES::in);//Starts the intake
            Drivetrain::straightForDistance(0_in);//Drives to the first set of discs
            Drivetrain::straightForDistance(0_in);//Drives to the next set of discs
            Drivetrain::straightForDistance(0_in);//Drives to the last set of discs
            Drivetrain::turn(0_deg);//Turns to the high goal
                IntakeStateMachine::setState(INTAKE_STATES::off);//Stops the Intake
            Drivetrain::moveBack(0);//Moves to the curb
                FlywheelStateMachine::setState(FW_STATES::a2);//Shoots into the high goal
            Drivetrain::straightForDistance(0_in);//Drives back from the roller
            Drivetrain::turn(0_deg);//Turns to face the other side of the field
            Drivetrain::straightForDistance(0_in);//Drives to the last roller
            Drivetrain::turn(0_deg);//Turns to face the last roller
            Drivetrain::moveDist();//Drives to the roller
            //    IntakeStateMachine::setState(INTAKE_STATES::RollerColor);;//Roll the color 4/4
            Drivetrain::straightForDistance(0_in);//Drives back from the roller
            Drivetrain::turn(0_deg);//Turns to face the field
                EndGameStateMachine::setState(END_STATES::on);//Fires the Endgame
        break;
        
        }
}

void Auton::startAsyncTaskWithSettings(std::function<bool()> iasyncCondition, std::function<void()> iasyncAction)
{
    masyncCondition = iasyncCondition;
    masyncAction = iasyncAction;
    masync_task.resume();
}
void Auton::async_task_func(void *)
{
    while (true)
    {
        if (masyncCondition())
        {
            masyncAction();
            masync_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<bool()> Auton::masyncCondition = []()
{ return false; };
std::function<void()> Auton::masyncAction;
pros::Task Auton::masync_task(Auton::async_task_func);

void Auton::startTaskAfterDelay(QTime idelay, std::function<void()> iaction)
{
    mdelayAction = iaction;
    mdelayTime = idelay;
    mdelay_task.resume();
}
void Auton::delay_task_func(void *)
{
    while (true)
    {
        if (mtimer.millis() - mstartTime > mdelayTime)
        {
            mdelayAction();
            mdelay_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<void()> Auton::mdelayAction;
Timer Auton::mtimer = Timer();
QTime Auton::mstartTime = 0_ms;
QTime Auton::mdelayTime = 2_min;
pros::Task Auton::mdelay_task(Auton::delay_task_func);