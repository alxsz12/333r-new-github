#include "definitions.hpp"
#include "main.h"
#include "okapi/api/units/QSpeed.hpp"
#include "okapi/api/util/logging.hpp"
#include "okapi/impl/device/motor/motorGroup.hpp"
#include "pros/motors.hpp"
#include "stateMachines/FlywheelStateMachine.hpp"
#include "stateMachines/IntakeStateMachine.hpp"

pros::Controller master (CONTROLLER_MASTER);// Gets the controller reference so that 
                                              // so that we can print to the controller
                                              // the voltage that the flywheel is currently
                                              // spinning at
int fwv = 10000;

FW_STATES FlywheelStateMachine::getState() { return mstate; }
void FlywheelStateMachine::setState(const FW_STATES istate)
{
    mstate = istate;
}

void FlywheelStateMachine::enableControl()
{
    mcontrolEnabled = true;
}

void FlywheelStateMachine::disableControl()
{
    mcontrolEnabled = false;
}
/*
void FlywheelStateMachine::vs(QSpeed ispeed, PID ipid){
    while (mcontrolEnabled && !ipid.isSettled())
    {
        double ferror = ispeed - mmotors.getVoltage();
        mmotors.moveVoltage(-ipid.iterate(ferror));
    }
}
*/
void FlywheelStateMachine::controlState(){
    if(mbtnShoot.changedToPressed()){
        if (getState() == FW_STATES::off) // if it's already shooting
            setState(FW_STATES::shoot);    // make it stop.
        else 
            setState(FW_STATES::off);  //Otherwise the flywheel should be off
    }
}   

void FlywheelStateMachine::speedu(){ // Function to be able to change the flywheel speed //AKA Speed Update 
    if(mbtnUp.changedToPressed()){   // by the voltage, and as you press the buttons  
        fwv+= 500;                   // the flywheel voltage will update by increments of 500
        //fwv = 11000;
        master.print(0, 0, "Flywheel: %d", fwv); // Then we can go and get the controller reference
    }                                // And print the new voltage after the voltage was changed
    if(mbtnDown.changedToPressed()){
         fwv-= 500;
        //fwv = 10000;
        master.print(0, 0, "Flywheel: %d", fwv);
    }
    master.print(0, 0, "Flywheel: %d", fwv); // Prints it at the end of the loop in case there was
    // a button pressed that did not register with printing on the screen
    if(fwv > 12000){
        fwv = 12000;
    }
    if(fwv < 0){
        fwv = 0;
    }
}

void FlywheelStateMachine::AShoot(int volt)
{
    mmtr.moveVoltage(volt);
    while(def::d_discs.get() < 90 && def::d_discs.get() != 0){
    //def::controller.rumble("-");
    mmtr.moveVoltage(volt);
        if(def::mtr_fw_fw.getActualVelocity() >= 180){
            def::mtr_it_m.moveVoltage(12000);
        }
    }
    pros::delay(2000);
    mmtr.moveVoltage(0); //stops the fly
    pros::delay(1000);
    def::mtr_it_m.moveVoltage(0); //stops the intake
    def::controller.rumble("-");
}

/*---------------------Flywheel PID----------------------*/
/*This will be used to try and have the flywheel operate */
/*around a set RPM using the RPM int variable and having */
/*PID iterate around the error that we are calculating   */
/*from the RPM value that we want, and the current       */
/*RPM that the flywheel rpm                              */
/*-------------------------------------------------------*/
void FlywheelStateMachine::pid(int RPM, PID ipid){
    while (mcontrolEnabled && !ipid.isSettled())
    {
        double error = RPM - (def::mtr_fw_fw.getActualVelocity());
        // mmotors.moveVoltage(ipid.iterate(error));
        mmtr.moveVoltage(ipid.iterate(error));
        pros::delay(20);
    }
    // mmotors.moveVoltage(0);
    mmtr.moveVoltage(0);
}
/*-------------------------------------------------------*/
/*-------------------------------------------------------*/
/*-------------------------------------------------------*/
 
void FlywheelStateMachine::update() // updates the subsystem based on the state
{
    switch (mstate)
    {
        case FW_STATES::off: // Turns the flywheel Off
            // mmotors.moveVoltage(0);
            mmtr.moveVoltage(0);
            break;
        case FW_STATES::shoot: // Spins the flywheel 
            mmtr.moveVoltage(fwv); //Moves the flywheel by the changeable variable
            //mmotors.moveVoltage(fwv);    
            //pid(3600);
            break;
        case FW_STATES::a2: // State for autonomous to shoot the two preloads then stop.
                // mmotors.moveVoltage(9000); //Starts the flywheel;
                mmtr.moveVoltage(12000);
                pros::delay(3000);
                IntakeStateMachine::setState(INTAKE_STATES::in);
                pros::delay(1000);
                mmtr.moveVoltage(0);
                IntakeStateMachine::setState(INTAKE_STATES::off);
            break;
    }
}

void FlywheelStateMachine::run()
{
    while (true)
    {
        def::display.setMiscData(1, "FW Actual: " + std::to_string(def::mtr_fw_fw.getActualVelocity()));
        def::display.setMiscData(2, "FW Target: " + std::to_string(def::mtr_fw_fw.getTargetVelocity()));
        //Updating the brain here so that we can accurately see where the current velocity is
        //in comparison to the actual target value that the PID has calculated. 
        //This helps with debugging flywheel issues as we think it is issues with the PID, but
        //it helps with figuring that the problem is not the PID, but rather the flywheel
        //needs to he tuned properly with the values printed on the brain here
        if (mcontrolEnabled)
                controlState();
            speedu(); // We can add the speed update function here to run
        update();     // and update the voltage so that it updates as often as possible
        pros::delay(20);
    }
}

/* ------------------------- Devices ------------------------- */
//MotorGroup FlywheelStateMachine::mmotors = MotorGroup({def::mtr_fw_fw1, def::mtr_fw_fw2});
Motor &FlywheelStateMachine::mmtr = def::mtr_fw_fw;
//This is where we are able to connect both of the motors together into a group
/* -------------------------- State -------------------------- */

//FW_STATES FlywheelStateMachine::moverrideState = FW_STATES::off;
FW_STATES FlywheelStateMachine::mstate = FW_STATES::off;

bool FlywheelStateMachine::mcontrolEnabled = false;

ControllerButton &FlywheelStateMachine::mbtnShoot = def::btn_fw_shoot;

ControllerButton &FlywheelStateMachine::mbtnUp = def::btn_fw_up;
ControllerButton &FlywheelStateMachine::mbtnDown = def::btn_fw_down;
